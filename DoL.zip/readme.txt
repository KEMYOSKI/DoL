Thanks for playing Dungeons of Love

The game is slightly incomplete with minimal bug testing

If you enjoy it then it has been worth my time.


Credits:
Created by: Kristopher Misey
Assisted by: Cameron Shafer, Kuo Zhang, Andrew Brust, Eric McNally